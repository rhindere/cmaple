./mac_cmaple_cli @cmaple_cli_parameters.parameters -ocf migrate_fmc.operations >cmaple_migrate_output.txt
